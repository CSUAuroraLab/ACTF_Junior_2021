### hashgame

#### [flag]

`ACTF{Now_y0u_M4y_kn0w_LLL_or_BKZ}`

#### [题解分析]

Learn LLL or BKZ to solve this challenge.