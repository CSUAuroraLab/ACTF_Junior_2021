on(window,'load',function(){

    var game = new Game();

    game.setup();

    event(game);
});