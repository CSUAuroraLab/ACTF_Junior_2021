```
sage exp.sage # 如果有报错,再执行下面语句
sage -python exp.sage.py your_ip your_port # 运行脚本
```

e.g. 

sage -python exp.sage.py 0.0.0.0 9999